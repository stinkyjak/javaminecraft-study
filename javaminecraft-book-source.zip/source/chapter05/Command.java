package com.javaminecraft;

class Command {
    public static void main(String[] arguments) {
        System.out.println("You have summoned " + arguments[0]
            + " " + arguments[1] + " mobs."
        );
    }
}
