package com.javaminecraft;	

public class Modem {
    double speed;

    public void displaySpeed() {
        System.out.println("Speed: " + speed + " Mbps");
    }
}
