package com.javaminecraft;

class Splash {
    public static void main(String[] arguments) {
        String greeting = "Blue warrior shot the food!";
        System.out.println(greeting);
    }
}
