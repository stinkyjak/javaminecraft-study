package com.javaminecraft;

class Variable {
   public static void main(String[] arguments) {
      int tops;
      float radius;
      char key = 'C';
      String playerName = "JeffStrongman";
   }
}
